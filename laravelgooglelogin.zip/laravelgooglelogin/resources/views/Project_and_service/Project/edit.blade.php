@extends('layouts.Project_app')
@section('content')



<div class="container-fluid ">
  <div class="row content">
    <div class="col-sm-2 sidenav">
      <h4>
        <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
      </h4>
    </div>



    <div class="col-sm-8 main">
      <div class="w3-row w3-padding-64">
        <div class="w3-twothird w3-container">
          <h2 style="text-align:center">แก้ไขข้อมูล</h2> <br>
          <article>
            <div class="container" style="font-size:20px;margin-left:50px">
              <form action="/action_page.php">
                <div class="row">
                  <div class="col-25">
                    <label for="fname">ชื่อโครงการ</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="fname" name="namepro" placeholder="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="lname">ผู้รับผิดชอบ</label>
                  </div>
                  <div class="col-75">
                    <select>
                      <option value="volvo">ธีรเจต</option>
                      <option value="saab">นราวิช</option>
                      <option value="opel">เจตพล</option>
                      <option value="audi">ธนารัก</option>
                    </select>
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">เลขกำกับ</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="lname" name="lastname" placeholder="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">ผู้รับบริการ</label>
                  </div>
                  <div class="col-75">
                    <select>
                      <option value="volvo">ธีรเจต</option>
                      <option value="saab">นราวิช</option>
                      <option value="opel">เจตพล</option>
                      <option value="audi">ธนารัก</option>
                    </select>
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">งบประมาณ</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="lname" name="lastname" placeholder="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">upload เอกสาร</label>
                  </div>
                  <div class="col-75">
                    <form action="upload.php" method="post" enctype="multipart/form-data">

                      <input type="file" name="fileToUpload" id="fileToUpload">
                    </form>
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">วันเปิดโครงการ</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="lname" name="lastname" placeholder="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">วันปิดโครงการ</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="lname" name="lastname" placeholder="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-25">
                    <label for="country">ปีงบประมาณ</label>
                  </div>
                  <div class="col-75">
                    <input type="text" id="lname" name="lastname" placeholder="">
                  </div>
                </div>

                <!-- <div class="col-75">
                                <select id="country" name="country">
                                  <option value="australia">Australia</option>
                                  <option value="canada">Canada</option>
                                  <option value="usa">USA</option>
                                </select>
                              </div> --><br>
                <div class="row">
                  <div class="sub">
                    <input type="submit" value="Submit">
                    <a href="tarhtml.html" class="btn btn-danger"> Back</a>

                  </div>
                </div>
            </div>

          </article>



        </div>

      </div>
    </div>
    <div class="col-sm-2 sidenav"></div>
  </div>
</div>
@endsection
@section('footer')

@endsection