

@extends('layouts.Varasan_app')
@section('content')
  
            <div class="container-fluid text-center">
                <div class="row content">
                    <div class="col-sm-2 sidenav">
                    <h4>
                <p><a href="./moufirst">หน้าแรกระบบ</a><br></p>
            </h4>
                    </div>
                    <div class="col-sm-8 main">
                        <h1>วารสาร</h1>
                        <br>
                        <table>
                            <tr>
                                <th>ชื่อผู้แต่ง</th>
                                <th>ปี ค.ศ.</th>
                                <th>ชื่อวารสาร</th>
                                <th>Vol.</th>
                                <th>No.</th>
                                <th>Page</th>
                                <th>PDF</th>
                                <th>Delete</th>
                            </tr>
                            <tr>
                                <td>Jill</td>
                                <td>Smith</td>
                                <td>50</td>
                                <td>Eve</td>
                                <td>Jackson</td>
                                <td>94</td>
                                <td>94</td>
                                <td>
                                    <input type="submit" value="ลบ">
                                </td>
                            </tr>
                            <tr>
                                <td>Jill</td>
                                <td>Smith</td>
                                <td>50</td>
                                <td>Eve</td>
                                <td>Jackson</td>
                                <td>94</td>
                                <td>94</td>
                                <td>
                                    <input type="submit" value="ลบ">
                                </td>
                            </tr>

                        </table>
                    </div>
                    <div class="col-sm-2 sidenav"></div>
                </div>
            </div>
 
            @endsection
    @section('footer')
    <p>footer</p>
    @endsection
