<?php $__env->startSection('content'); ?>


      <div class="container-fluid ">
          <div class="row content">
              <div class="col-sm-2 sidenav">
              <a href="search_service" > Search page</a>
                          <a href="service_view"> viewdata page</a>
              </div>



              <div class="col-sm-8 main">
                <div class="w3-row w3-padding-64">
                  <div class="w3-twothird w3-container">
                    <h1 class="w3-text-teal">edit บริการ</h1>
                    <div class="topnav">
                      <a class="active"></a>
                      <div class="container">
                        <form action="/action_page.php">
                          <div class="w3-row w3-padding-64">
                            <div class="col-75">
                              <label for="fname">โครงการ</label>
                            </div>
                            <div class="col-75">
                              <input type="text" id="fname" name="namepro" placeholder="">
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="lname">ชื่อผู้รับผิดชอบ</label>
                            </div>
                            <div class="col-75">
                              <select>
                                <option value="volvo">อาจาร a</option>
                                <option value="saab">อาจาร b</option>
                                <option value="opel">อาจาร c</option>
                                <option value="audi">อาจาร d</option>
                              </select>
                            </div>
                          </div>

                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">เลขกำกับโครงการ</label>
                            </div>
                            <div class="col-75">
                              <input type="text" id="lname" name="lastname" placeholder="">
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">ชื่อผู้รับบริการ</label>
                            </div>
                            <div class="col-75">
                              <select>
                                <option value="volvo">1</option>
                                <option value="saab">2</option>
                                <option value="opel">3</option>
                              </select>
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">งบประมาณทั้งหมดที่มี</label>
                            </div>
                            <div class="col-75">
                              <input type="text" id="lname" name="lastname" placeholder="">
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">upload new work</label>
                            </div>
                            <div class="col-75">
                              <form action="upload.php" method="post" enctype="multipart/form-data">
                                <input type="file" name="fileToUpload" id="fileToUpload">
                                  <div class="subb">
                                    <input type="submit" value="Submit">
                                  </div>
                              </form>
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">วันเริ่มเปิดโครงการ</label>
                            </div>
                            <div class="col-75">
                              <input type="text" id="lname" name="lastname" placeholder="">
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">วันที่ปิดโครงการ</label>
                            </div>
                            <div class="col-75">
                              <input type="text" id="lname" name="lastname" placeholder="">
                            </div>
                          </div>
                          <div class="w3-row w3-padding-64">
                            <div class="col-25">
                              <label for="country">ปีที่ได้รับงบประมาณ</label>
                            </div>
                            <div class="col-75">
                              <input type="text" id="lname" name="lastname" placeholder="">
                            </div>
                          </div>
                        </div>
                        <a href="./confirm"><input type="button" value="Finish" class="btn btn-default"></a>
                   
                      </div>
                    </div>
                  </div>

              </div>
            </div>
            <section>

<article>




        <!-- <div class="col-75">
          <select id="country" name="country">
            <option value="australia">Australia</option>
            <option value="canada">Canada</option>
            <option value="usa">USA</option>
          </select>
        </div> -->
        <div class="row">
          <div class="sub">
          <input type="submit" value="Submit">
          </div>
        </div>
       

</article>
</section>
      </div>

      <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer'); ?>
    <p>footer</p>
    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.Service_app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>