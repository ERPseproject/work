<?php $__env->startSection('content'); ?>


    <!--Main Content-->
  
            <div class="container-fluid text-center">
                <!--Side Menu-->
                <div class="row content">
                    <div class="col-sm-2 sidenav">
                        <p><a href="./kurupan">ระบบคุรุภัณฑ์</a></p>  
                    </div>
                    <!--Main Menu-->
                    <div class="col-sm-8 main">
                            <div class="w3-twothird w3-container">
                                    <form>
                                    <div class="table-responsive">          
                                        <table class="table">
                                        <thead>
                                            <tr>
                                            <th>ชื่อ</th>
                                            <th>รหัส</th>
                                            <th>สถานะการซื้อ</th>
                                            <th>ตำแหน่งที่ตั้ง</th>
                                            <th>วันที่จัดซื้อ</th>
                                            <th>ราคา</th>
                                            <th>ผู้รับผิดชอบ</th>
                                            <th>วันจำหน่ายออก</th>
                                            <th>ผู้รับซื้อ</th>
                                            <th>           
                                                <a href="#">
                                                    <span class="glyphicon glyphicon-picture"></span>
                                                </a>
                                            </th>     
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <!-- database -->
                                                
                                        </tbody>
                                        </table>
                                    </div>
                                    </form>
                                </div>
                    </div>
                    <div class="col-sm-2 sidenav"></div>
                </div>
            </div>
        
        <?php $__env->stopSection(); ?>
    <?php $__env->startSection('footer'); ?>
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Kurupan_app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>